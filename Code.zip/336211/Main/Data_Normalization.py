import numpy as np

def juttler_korth_normalization(X):
    X = np.asarray(X, dtype=float)

    # Maximum value of each feature/column
    maximum = np.max(X, axis=0)

    # Avoid division by zero
    maximum_safe = np.where(maximum == 0, 1, maximum)

    # Jüttler-Körth normalization
    X_norm = 1 - np.abs(
        (maximum - X) / maximum_safe
    )

    return X_norm