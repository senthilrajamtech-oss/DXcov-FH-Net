import numpy as np
from sklearn.linear_model import ElasticNet
from sklearn.preprocessing import StandardScaler


def select_fea(X, y, n_fs, phi=0.5):

    X = np.asarray(X, dtype=float)
    y = np.asarray(y)

    # ---------------------------------------------------------
    # Standardize features for Elastic Net
    # ---------------------------------------------------------
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # ---------------------------------------------------------
    #  Elastic Net feature selection
    # ---------------------------------------------------------
    model = ElasticNet(
        alpha=0.01,
        l1_ratio=0.5,
        max_iter=10000,
        random_state=42
    )

    model.fit(X_scaled, y)

    # Absolute Elastic Net coefficient
    elastic_importance = np.abs(model.coef_)

    # ---------------------------------------------------------
    # Calculate correlation coefficient
    # ---------------------------------------------------------
    correlation_importance = np.zeros(X.shape[1])

    for i in range(X.shape[1]):
        # Avoid division by zero for constant features
        if np.std(X[:, i]) == 0 or np.std(y) == 0:
            correlation_importance[i] = 0.0
        else:
            corr = np.corrcoef(X[:, i], y)[0, 1]
            if np.isnan(corr):
                corr = 0.0
            correlation_importance[i] = abs(corr)

    # ---------------------------------------------------------
    #Normalize Elastic Net importance
    # ---------------------------------------------------------
    if np.max(elastic_importance) > 0:
        elastic_importance_norm = (
            elastic_importance /
            np.max(elastic_importance)
        )
    else:
        elastic_importance_norm = elastic_importance

    # ---------------------------------------------------------
    # Correlation coefficient is already in [0, 1]
    # ---------------------------------------------------------
    correlation_norm = correlation_importance

    # ---------------------------------------------------------
    # Combine Elastic Net and correlation
    #
    # Final Score = phi * ElasticNet
    #             + (1 - phi) * Correlation
    # ---------------------------------------------------------
    final_score = (
        phi * elastic_importance_norm
        + (1 - phi) * correlation_norm
    )

    # ---------------------------------------------------------
    # Select top n_fs features
    # ---------------------------------------------------------
    n_fs = min(n_fs, X.shape[1])

    top_indices = np.argsort(
        final_score
    )[-n_fs:][::-1]

    # ---------------------------------------------------------
    # Final selected feature matrix
    # ---------------------------------------------------------
    X_selected = X[:, top_indices]

    return X_selected