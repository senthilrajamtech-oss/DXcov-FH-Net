import pandas as pd
import numpy as np
import Data_Normalization
import Feature_Selection
import Data_Augumentation
import Proposed_DXcov_FH_Net.DXcov_FH_Net

def callmain(dts,Ld):
    ACC,TPR,TNR=[],[],[]
    # recorded log file
    data_=pd.read_csv('Dataset/'+dts+".csv")
    data_=np.array(data_)
    Data = data_[:, :-1]
    Label=data_[:,-1]
    # Data normalization using Juttler-Korth Normalization technique
    Norm_data=Data_Normalization.juttler_korth_normalization(Data)
    n_fs=10   # Number of features need to be selected
    # feature Selection using ElasticNet and Correlation coefficient  and correlation coefficient
    Sel_fea=Feature_Selection.select_fea(Norm_data,Label,n_fs)
    # Data augmentation using oversampling
    Aug_data,Aug_label=Data_Augumentation.oversample_data(Sel_fea,Label)
    # Intrusion detection using XCovNet and DSA
    Proposed_DXcov_FH_Net.DXcov_FH_Net.callmain_dxcov_fhnet(Aug_data,Aug_label,Ld,ACC,TPR,TNR)
    return ACC,TPR,TNR


