from imblearn.over_sampling import SMOTE
import numpy as np


def oversample_data(X, y):
    """
    Oversample the minority class using SMOTE.
    """

    X = np.asarray(X, dtype=float)
    y = np.asarray(y)

    smote = SMOTE(
        sampling_strategy='auto',
        random_state=42
    )

    X_aug, y_aug = smote.fit_resample(X, y)

    return X_aug, y_aug