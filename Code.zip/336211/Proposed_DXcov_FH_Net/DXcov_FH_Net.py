import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score,recall_score,confusion_matrix,roc_auc_score)

# DXCOV-FHNet

class DXCOV_FHNet:

    def __init__(
        self,
        n_features,
        learning_rate=0.001
    ):

        self.n_features = n_features
        self.learning_rate = learning_rate

        # ----------------------------------------------------
        # XCovNet parameters
        # ----------------------------------------------------

        self.w = np.random.randn(
            n_features
        ) * 0.01

        self.b = 0.0

        self.v1_k = np.random.randn(
            n_features
        ) * 0.01

        self.w_i = np.random.randn(
            n_features
        ) * 0.01

        # ----------------------------------------------------
        # DSA parameters
        # ----------------------------------------------------

        self.w1 = np.random.randn(
            n_features
        ) * 0.01

        self.b1 = 0.0

        self.w2 = np.random.randn(
            n_features
        ) * 0.01

        self.b2 = 0.0

        # ----------------------------------------------------
        # Classification layer
        # ----------------------------------------------------

        self.classifier_w = np.random.randn(
            n_features
        ) * 0.01

        self.classifier_b = 0.0

    # ========================================================
    # XCovNet
    # ========================================================

    def xcov_net_forward(self, Ag):

        sum_wi_ag = np.sum(
            self.w_i * Ag
        )

        term1 = (
            self.w
            * self.v1_k
            * Ag
        )

        term2 = (
            self.b
            * self.v1_k
            * sum_wi_ag
        )

        y1 = term1 + term2

        return y1

    # ========================================================
    # DSA
    # ========================================================

    def dsa_forward(self, Ag):

        linear = (
            Ag * self.w1
            + self.b1
        )

        harmonic = (
            np.sin(linear)
            +
            np.cos(
                Ag * self.w2
            )
        )

        y2 = linear * harmonic

        return y2

    # ========================================================
    # Harmonic prediction
    # ========================================================

    def time_series_prediction(
        self,
        x_t_minus_1,
        x_t,
        t
    ):

        term1 = (
            x_t_minus_1
            *
            (
                1.0
                - np.cos(
                    np.pi * t
                )
            )
            / 2.0
        )

        term2 = (
            x_t
            *
            (
                1.0
                + np.cos(
                    np.pi * t
                )
            )
            / 2.0
        )

        return term1 + term2

    # ========================================================
    # a0
    # ========================================================

    def compute_a0(
        self,
        x1,
        x2
    ):

        return 0.5 * (
            x1 + x2
        )

    # ========================================================
    # Harmonic series
    # ========================================================

    def compute_harmonic_series(
        self,
        a0,
        a_coeffs,
        b_coeffs,
        t,
        V
    ):

        result = a0

        for n in range(
            1,
            V + 1
        ):

            an = (
                a_coeffs[n - 1]
                if n - 1 < len(a_coeffs)
                else 0.0
            )

            bn = (
                b_coeffs[n - 1]
                if n - 1 < len(b_coeffs)
                else 0.0
            )

            result += (
                an
                * np.cos(
                    2.0
                    * np.pi
                    * n
                    * t
                    / V
                )
                +
                bn
                * np.sin(
                    2.0
                    * np.pi
                    * n
                    * t
                    / V
                )
            )

        return result

    # ========================================================
    # Sigmoid
    # ========================================================

    def sigmoid(self, z):

        z = np.clip(
            z,
            -50,
            50
        )

        return 1.0 / (
            1.0 + np.exp(-z)
        )

    # ========================================================
    # Forward pass
    # ========================================================

    def forward(
        self,
        Ag,
        x_t_minus_1,
        x_t,
        t
    ):

        # XCovNet
        y1 = self.xcov_net_forward(
            Ag
        )

        # DSA
        y2 = self.dsa_forward(
            Ag
        )

        # Harmonic prediction
        next_state = (
            self.time_series_prediction(
                x_t_minus_1,
                x_t,
                t
            )
        )

        # a0
        a0 = self.compute_a0(
            x_t_minus_1,
            x_t
        )

        # ----------------------------------------------------
        # Harmonic fusion
        # ----------------------------------------------------

        y3 = (
            y1
            + y2
            + next_state
            + a0
        )

        # ----------------------------------------------------
        # Classification
        # ----------------------------------------------------

        score = np.sum(
            y3
            * self.classifier_w
        ) + self.classifier_b

        probability = self.sigmoid(
            score
        )

        return {
            "y1": y1,
            "y2": y2,
            "next_state": next_state,
            "a0": a0,
            "y3": y3,
            "score": score,
            "probability": probability
        }

    # ========================================================
    # Training
    # ========================================================

    def train(
        self,
        X_train,
        y_train,
        epochs=20
    ):

        X_train = np.asarray(
            X_train,
            dtype=float
        )

        y_train = np.asarray(
            y_train,
            dtype=float
        )

        n_samples = len(
            X_train
        )

        for epoch in range(
            epochs
        ):

            total_loss = 0.0

            # Shuffle training data
            indices = np.random.permutation(
                n_samples
            )

            X_shuffled = X_train[
                indices
            ]

            y_shuffled = y_train[
                indices
            ]

            # --------------------------------------------
            # Sample-wise training
            # --------------------------------------------

            for i in range(
                n_samples
            ):

                Ag = X_shuffled[i]

                if i == 0:
                    x_prev = Ag
                else:
                    x_prev = X_shuffled[i - 1]

                x_curr = Ag

                output = self.forward(
                    Ag,
                    x_prev,
                    x_curr,
                    float(i)
                )

                probability = (
                    output["probability"]
                )

                target = y_shuffled[i]

                # ----------------------------------------
                # Binary cross entropy
                # ----------------------------------------

                eps = 1e-8

                loss = -(
                    target
                    * np.log(
                        probability + eps
                    )
                    +
                    (1.0 - target)
                    * np.log(
                        1.0
                        - probability
                        + eps
                    )
                )

                total_loss += loss

                # ----------------------------------------
                # Gradient of BCE + sigmoid
                # ----------------------------------------

                error = (
                    probability
                    - target
                )

                # ----------------------------------------
                # Classification-layer update
                # ----------------------------------------

                grad_classifier_w = (
                    error
                    * output["y3"]
                )

                grad_classifier_b = (
                    error
                )

                self.classifier_w -= (
                    self.learning_rate
                    * grad_classifier_w
                )

                self.classifier_b -= (
                    self.learning_rate
                    * grad_classifier_b
                )

            # --------------------------------------------
            # Epoch loss
            # --------------------------------------------

            avg_loss = (
                total_loss
                / n_samples
            )

            if (
                epoch == 0
                or
                (epoch + 1) % 5 == 0
            ):

                print(
                    f"Epoch "
                    f"{epoch + 1:3d}/{epochs} "
                    f"Loss: "
                    f"{avg_loss:.6f}"
                )

    # ========================================================
    # Prediction
    # ========================================================

    def predict_proba(
        self,
        X
    ):

        X = np.asarray(
            X,
            dtype=float
        )

        probabilities = []

        for i in range(
            len(X)
        ):

            Ag = X[i]

            if i == 0:
                x_prev = Ag
            else:
                x_prev = X[i - 1]

            output = self.forward(
                Ag,
                x_prev,
                Ag,
                float(i)
            )

            probabilities.append(
                output["probability"]
            )

        return np.asarray(
            probabilities
        )

    # ========================================================
    # Class prediction
    # ========================================================

    def predict(
        self,
        X,
        threshold=0.5
    ):

        probabilities = (
            self.predict_proba(X)
        )

        return (
            probabilities >= threshold
        ).astype(int)


# ============================================================
# COMPLETE TRAINING + TESTING FUNCTION
# ============================================================

def callmain_dxcov_fhnet(data,label,tr,ACC,TPR,TNR):

    # --------------------------------------------------------
    # Convert data
    # --------------------------------------------------------

    X = np.asarray(
        data,
        dtype=float
    )

    y = np.asarray(
        label
    ).reshape(-1)


    # --------------------------------------------------------
    # Train / test split
    # --------------------------------------------------------

    (
        X_train,
        X_test,
        y_train,
        y_test
    ) = train_test_split(
        X,
        y,
        train_size=tr,
        stratify=y,
        random_state=42
    )

    # --------------------------------------------------------
    # Initialize network
    # --------------------------------------------------------

    model = DXCOV_FHNet(
        n_features=X_train.shape[1],
        learning_rate=0.001
    )


    # Training

    model.train(
        X_train,
        y_train,
        epochs=100
    )

    # --------------------------------------------------------
    # Testing
    # --------------------------------------------------------


    y_probability = (
        model.predict_proba(
            X_test
        )
    )

    y_pred = (
        y_probability >= 0.5
    ).astype(int)

    # Confusion matrix

    cm = confusion_matrix(
        y_test,
        y_pred
    )


    # Binary metrics

    accuracy = accuracy_score(
        y_test,
        y_pred
    )

    tpr = recall_score(
        y_test,
        y_pred,
        zero_division=0
    )

    # TNR

    if cm.shape == (2, 2):

        tn, fp, fn, tp = cm.ravel()

        tnr = (
            tn / (tn + fp)
            if (tn + fp) != 0
            else 0.0
        )


    # ROC-AUC

    try:

        auc = roc_auc_score(
            y_test,
            y_probability
        )

    except ValueError:

        auc = np.nan

    ACC.append(accuracy*100)
    TPR.append(tpr*100)
    TNR.append(tnr*100)